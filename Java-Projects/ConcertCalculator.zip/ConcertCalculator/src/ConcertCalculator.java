/**
 *
 * @author David
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ConcertCalculator extends JFrame implements ActionListener{
    
    private static final int FRAME_WIDTH = 360;
    private static final int FRAME_HEIGHT = 550;
    
    private static String ACount;
    private static String BCount;
    private static String CCount;
    private static String APrice;
    private static String BPrice;
    private static String CPrice;
    
    // form objects
    private JButton btnCreate;
    private JButton btnReset;
    private JTextField txtACount;
    private JTextField txtBCount;
    private JTextField txtCCount;
    private JTextField txtAPrice;
    private JTextField txtBPrice;
    private JTextField txtCPrice;
    private JTextArea txtReport;
    private JLabel lblCount;
    private JLabel lblPrice;
    private JLabel lblSeatA;
    private JLabel lblSeatB;
    private JLabel lblSeatC;
    
    public ConcertCalculator(){
        
        this.setTitle("Concert Ticket Calculator");
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setResizable(false);
        
        // initializing objects
        btnCreate = new JButton("Create Report");
        btnCreate.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        lblCount = new JLabel("Count");
        lblPrice = new JLabel("Price ($)");
        lblSeatA = new JLabel("Enter for Seat A:");
        lblSeatB = new JLabel("Enter for Seat B:");
        lblSeatC = new JLabel("Enter for Seat C:");
        
        txtACount = new JTextField();
        txtACount.setColumns(12);
        txtACount.addActionListener(this);
        
        txtBCount = new JTextField();
        txtBCount.setColumns(12);
        txtBCount.addActionListener(this);
        
        txtCCount = new JTextField();
        txtCCount.setColumns(12);
        txtCCount.addActionListener(this);
        
        txtAPrice = new JTextField();
        txtAPrice.setColumns(12);
        txtAPrice.addActionListener(this);
        
        txtBPrice = new JTextField();
        txtBPrice.setColumns(12);
        txtBPrice.addActionListener(this);
        
        txtCPrice = new JTextField();
        txtCPrice.setColumns(12);
        txtCPrice.addActionListener(this);
        
        txtReport = new JTextArea();
        txtReport.setColumns(20);
        txtReport.setRows(5);
        txtReport.setEditable(false);
        txtReport.setLineWrap(true);
        txtReport.setWrapStyleWord(true);
        txtReport.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        txtReport.setFont(new Font("Courier", Font.PLAIN, 14));
        
        // JPanel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());        
        this.add(contentPanel);
        
        // JPanels input Data
        JPanel inputData = new JPanel();
        inputData.setBorder(BorderFactory.createTitledBorder("Enter Data"));
        inputData.setLayout(new BoxLayout(inputData, BoxLayout.Y_AXIS));
 
        JPanel countPrice = new JPanel();
        countPrice.setLayout(new BoxLayout(countPrice, BoxLayout.X_AXIS));
        countPrice.add(Box.createRigidArea(new Dimension(125, 0)));
        countPrice.add(lblCount);
        countPrice.add(Box.createRigidArea(new Dimension(85, 0)));
        countPrice.add(lblPrice);
        inputData.add(countPrice);
        
        JPanel seatA = new JPanel();
        seatA.setLayout(new BoxLayout(seatA, BoxLayout.X_AXIS));
        seatA.add(Box.createRigidArea(new Dimension(5, 0)));
        seatA.add(lblSeatA);
        seatA.add(Box.createRigidArea(new Dimension(5, 0)));
        seatA.add(txtACount);
        seatA.add(Box.createRigidArea(new Dimension(5, 0)));
        seatA.add(txtAPrice);
        inputData.add(seatA);
        
        JPanel seatB = new JPanel();
        seatB.setLayout(new BoxLayout(seatB, BoxLayout.X_AXIS));
        seatB.add(Box.createRigidArea(new Dimension(5, 0)));
        seatB.add(lblSeatB);
        seatB.add(Box.createRigidArea(new Dimension(5, 0)));
        seatB.add(txtBCount);
        seatB.add(Box.createRigidArea(new Dimension(5, 0)));
        seatB.add(txtBPrice);
        inputData.add(seatB);
        
        JPanel seatC = new JPanel();
        seatC.setLayout(new BoxLayout(seatC, BoxLayout.X_AXIS));
        seatC.add(Box.createRigidArea(new Dimension(5, 0)));
        seatC.add(lblSeatC);
        seatC.add(Box.createRigidArea(new Dimension(5, 0)));
        seatC.add(txtCCount);
        seatC.add(Box.createRigidArea(new Dimension(5, 0)));
        seatC.add(txtCPrice);
        inputData.add(seatC);
         
        //JPanel Report
        JPanel reportData = new JPanel();
        reportData.setBorder(BorderFactory.createTitledBorder("Report"));
        reportData.setLayout(new BorderLayout(10,10));
        reportData.add(Box.createRigidArea(new Dimension(5, 0)), BorderLayout.NORTH);
        reportData.add(Box.createRigidArea(new Dimension(2, 0)), BorderLayout.LINE_START);
        reportData.add(txtReport, BorderLayout.CENTER);
        reportData.add(Box.createRigidArea(new Dimension(2, 0)), BorderLayout.LINE_END);
        reportData.add(Box.createRigidArea(new Dimension(5, 0)), BorderLayout.SOUTH);
        
        //JPanel Buttons
        JPanel buttonData = new JPanel();
        buttonData.setLayout(new BoxLayout(buttonData, BoxLayout.X_AXIS));
        buttonData.setBorder(BorderFactory.createEmptyBorder(15, 10, 10, 10));
        buttonData.add(Box.createRigidArea(new Dimension(75, 10)));
        buttonData.add(btnCreate);
        buttonData.add(Box.createRigidArea(new Dimension(5, 0)));
        buttonData.add(btnReset);
        
        
        contentPanel.add(inputData, BorderLayout.NORTH);
        contentPanel.add(reportData, BorderLayout.CENTER);
        contentPanel.add(buttonData, BorderLayout.SOUTH);
    }
    
    @Override
    public void actionPerformed(ActionEvent event) {
        if ((event.getSource() == btnCreate)) {
            // setting variables
            setACount();
            setBCount();
            setCCount();
            setAPrice();
            setBPrice();
            setCPrice();
            // calculation and report
            Seat seat = new Seat();
            Report report = new Report();
            txtReport.setText(Report.getReport());
        }
        else if (event.getSource() == btnReset){
            txtACount.setText("");
            txtBCount.setText("");
            txtCCount.setText("");
            txtAPrice.setText("");
            txtBPrice.setText("");
            txtCPrice.setText("");
            txtReport.setText("");
            txtACount.requestFocusInWindow();
        }
    }
    // gets sets
    public void setACount(){
        ACount = txtACount.getText();
    }
    public void setBCount(){
        BCount = txtBCount.getText();
    }
    public void setCCount(){
        CCount = txtCCount.getText();
    }
    public void setAPrice(){
        APrice = txtAPrice.getText();
    }
    public void setBPrice(){
         BPrice = txtBPrice.getText();
    }
    public void setCPrice(){
         CPrice = txtCPrice.getText();
    }
    public static String getACount(){
        return ACount;
    }
    public static String getBCount(){
        return BCount;
    }
    public static String getCCount(){
        return CCount;
    }
    public static String getAPrice(){
        return APrice;
    }
    public static String getBPrice(){
        return BPrice;
    }
    public static String getCPrice(){
        return CPrice;
    }
    
    // main class
    public static void main(String[] args) {
        ConcertCalculator ticketForm;
        ticketForm = new ConcertCalculator();
        ticketForm.setVisible(true);
    }
    
}
