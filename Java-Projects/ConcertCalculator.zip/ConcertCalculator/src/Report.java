/**
 *
 * @author David
 */
public class Report {

    
    public static String getReport(){
        return    "             Tickets sold   Price        Total" + "\n"
                + "             ---------------   ------        -----" + "\n"
                + "Seat A       " + ConcertCalculator.getACount() + "             "
                + "$" + "\b" + ConcertCalculator.getAPrice() + "          " 
                + "$" + "\b" + Seat.getATotal() + "\n"
                + "Seat B       " + ConcertCalculator.getBCount() + "             "
                + "$" + "\b" + ConcertCalculator.getBPrice() + "          " 
                + "$" + "\b" + Seat.getBTotal() + "\n"
                + "Seat C       " + ConcertCalculator.getCCount() + "             "
                + "$" + "\b" + ConcertCalculator.getCPrice() + "          " 
                + "$" + "\b" + Seat.getCTotal() + "\n"
                + "\n" + "Total Sales: $ " + Seat.getTotalSales();
    }
}
