/**
 *
 * @author David
 */
public class Seat {
    private static int seatATotal;
    private static int seatBTotal;
    private static int seatCTotal;
    
    public Seat(){
        seatATotal = (Integer.parseInt(ConcertCalculator.getACount()) * Integer.parseInt(ConcertCalculator.getAPrice()));
        seatBTotal = (Integer.parseInt(ConcertCalculator.getBCount()) * Integer.parseInt(ConcertCalculator.getBPrice()));
        seatCTotal = (Integer.parseInt(ConcertCalculator.getCCount()) * Integer.parseInt(ConcertCalculator.getCPrice()));
        
        
    }
    // gets
    public static int getATotal(){
        return seatATotal;
    }
    public static int getBTotal(){
        return seatBTotal;
    }
    public static int getCTotal(){
        return seatCTotal;
    }
    public static int getTotalSales(){
        return seatATotal + seatBTotal + seatCTotal;
    }
}
